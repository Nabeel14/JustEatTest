1) How long did you spend on the technical test? What would you add to your solution if you had more time? If you didn't spend much time on the technical 
test then use this as an opportunity to explain what you would add.

Answer: I spent an hour working technical on the test. If I had more time i would add an object repository to easily manage element locators. 
I would also add an excel file to provide data driven testing. I wou and integrate the test with jenkins if available if working on a real project. 
Lastly i would write the code in a page object model format to break up the tests for more clarity and organization.

2) What do you think is the most interesting trend in test automation?

Answer: I think the most interesting trend I have seen in automation is Model-Based Testing. At RBC I was working on a project with Robot Automation. I started 
using the program ConformIQ after some time which requires the user to make a model of their application in the areas they wanted to test. After modeling the 
application it would be able to export writtien test cases as well as automated cases if a scriptor was selected. I used the Robot Framework Scriptor after 
manually writing some automation for a similar test and the scriptor was able to write a script that needed little modification and provided fast script 
writing abilities.

3)  How would you implement test automation in a legacy application? Have you ever had to do this?

Answer: I have not had to implement test automatoin on a lageacy application. I have written automation for an RBC Salesforce.com portal that was having its legacy
 UI upgraded. Before the UI was planned to be upgraded, I was assigned to test the legacy version of the UI and i automated some test cases for it for 
quick execution after patches were applied to the application.

4) How would you improve the customer experience of the JUST EAT website?

Answer: To improve the customer experience, I would add a location sharing option because I am in Canada and the site supposed to be in the UK. Since there is a 
canadian site available, it should not let me order from restaraunts in the UK. Also the design for the pop-ups when adding items to the card are too confusing to navigate
I'd like it to be re-designed to be more readable and for the user to distinguish what options are being selected for what item especially when it comes to adding combos 
that require furter selection in the popup. It also is asking me to re-select mandatory items in the order within the pop-up again which is redundant.

5) Please describe yourself using JSON.

Answer:

{
"Me":{ "name":"Nabeel Iqbal", "age":29, "city":"Toronto", "favorite_sport":"Basketball" }
}

