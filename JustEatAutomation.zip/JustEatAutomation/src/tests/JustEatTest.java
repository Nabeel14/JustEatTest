package tests;

import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



	

	public class JustEatTest {
		
		public static WebDriver driver;
		
		@Test
		public void Login() {
			try {
			//Imply up to 40 second wait until element is found
		
			//Open Main Website
			startBrowser("chrome", "http://www.just-eat.co.uk/");
			 //Search for restaraunts with specific postal code
			WebDriverWait wait = new WebDriverWait(driver, 40);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='postcode']"))).sendKeys("AR51 1AA");
		
		
			 //Click the submit button to search
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']"))).click();
			driver.close();
			}
			catch (Exception e) {
				driver.close();
			}

		}
		// method to chose Browser to launch. Only Chrome is filled fully with its driver path set for now
	public static WebDriver startBrowser(String browserName, String url){
			
			if(browserName.equalsIgnoreCase("firefox")){
				driver = new FirefoxDriver();
			}
			if(browserName.equalsIgnoreCase("chrome")){
				//There needs to be the most up to date chromedriver for the version of the browser you are useing and Eclipse must be run as an administrator before running this program
				String path= "C:\\selenium-java-3.14.0\\drivers\\chromedriver.exe";
				System.setProperty("webdriver.chrome.driver", path);
				driver = new ChromeDriver();
			}
			if(browserName.equalsIgnoreCase("IE")){
				driver = new InternetExplorerDriver();
			}
			driver.manage().window().maximize();
			driver.get(url);
			return driver;
		}
	}
	


	
	